# heyu_app
It's a multilingual web application about displaying the features of messaging application.

**Languages and Tools:**
- Html5.
- Css.
- Bootstrap Framework.
- Sass.
- Pure Javascript, no frameworks or libraries.
- FontAwesome.

**To Preview Go To** [HeyU](https://heyu.netlify.com/).
